Message Ledger App Review Sample Data
====================================

This package contains a synthetic Messages source and optional synthetic
Contacts vCard for reviewing Message Ledger. It contains no real Messages,
Contacts, phone numbers, email domains, or personal user data.

Included files:

- Messages/chat.db
  Synthetic Messages database for Message Ledger review.

- Contacts/message-ledger-demo-contacts.vcf
  Optional fictional Contacts vCard with generated portrait photos. Importing
  it lets Message Ledger show the same fictional names and avatars used in the
  App Store screenshots. The app remains usable without importing Contacts.

Review setup:

1. Download and unzip this package.
2. Launch Message Ledger.
3. When Message Ledger asks for a Messages folder, choose the unzipped
   "Messages" folder that contains chat.db.
4. Allow the app to build its local analytics cache.
5. Optional: import Contacts/message-ledger-demo-contacts.vcf into Contacts and
   allow Contacts access in Message Ledger to see fictional names/photos.
6. Use Refresh or Rebuild Cache in Message Ledger if you need to rerun import.

Data boundaries:

- Message Ledger opens chat.db read-only.
- The sample chat.db is synthetic and was generated for App Review.
- Raw sample message text is present only to exercise aggregate analytics such
  as text length, emoji, reactions, shared items, activity, and timelines.
- Message Ledger does not send the source database to a developer server.

Sample coverage:

- Visible messages: 62556
- Source message rows: 78194
- Reaction rows: 15638
- Shared-item attachment rows: 3759
- Rich-link rows: 1909
- Chats: 16
- Handles: 26
- Fictional Contacts: 20
- Embedded Contact photos: 20
- Date span: 2019-07-01 to 2026-06-27

Stable download URL:

https://fmnobar.github.io/message-ledger-pages/review/MessageLedger-AppReview-SampleData.zip
